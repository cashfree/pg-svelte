// Using a symbol ensures the context key is unique
export const key = Symbol('cashfree');
